CREATE TRIGGER `delete`
AFTER DELETE ON `tb_meizhi`
FOR EACH ROW
  BEGIN
delete from  tb_person where id=old.id;
END