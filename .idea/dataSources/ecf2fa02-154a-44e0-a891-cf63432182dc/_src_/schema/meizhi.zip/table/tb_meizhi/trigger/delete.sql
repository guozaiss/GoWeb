CREATE TRIGGER `delete`
AFTER DELETE ON `tb_meizhi`
FOR EACH ROW
  BEGIN
call tb_person_deleteById(old.id);
END