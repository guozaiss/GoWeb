CREATE TRIGGER `update`
AFTER UPDATE ON `tb_meizhi`
FOR EACH ROW
  BEGIN
update tb_person set name=new.fileName where id =old.id;
END