CREATE TRIGGER `update`
AFTER UPDATE ON `tb_meizhi`
FOR EACH ROW
  BEGIN
update tb_person set id=new.id where id =old.id;
END