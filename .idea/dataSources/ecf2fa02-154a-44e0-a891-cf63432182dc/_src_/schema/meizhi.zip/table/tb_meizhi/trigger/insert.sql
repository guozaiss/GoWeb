CREATE TRIGGER `insert`
BEFORE INSERT ON `tb_meizhi`
FOR EACH ROW
  BEGIN
call meizhi.tb_person_insert(new.id,0,new.fileName);
END