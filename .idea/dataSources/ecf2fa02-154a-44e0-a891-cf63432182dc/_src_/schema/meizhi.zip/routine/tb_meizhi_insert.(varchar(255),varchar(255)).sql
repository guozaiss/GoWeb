CREATE PROCEDURE `tb_meizhi_insert`(IN `id` VARCHAR(255), IN `fileName` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	INSERT tb_meizhi(id,fileName) VALUES(id,fileName);
END