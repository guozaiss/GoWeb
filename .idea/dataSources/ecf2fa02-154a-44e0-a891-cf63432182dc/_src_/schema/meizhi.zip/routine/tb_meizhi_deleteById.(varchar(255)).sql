CREATE PROCEDURE `tb_meizhi_deleteById`(IN `whereBy` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	DELETE FROM tb_meizhi WHERE id= whereBy;
END