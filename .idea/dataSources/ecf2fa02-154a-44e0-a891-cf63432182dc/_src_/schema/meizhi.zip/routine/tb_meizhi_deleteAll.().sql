CREATE PROCEDURE `tb_meizhi_deleteAll`()
  BEGIN
	#Routine body goes here...
	DELETE FROM tb_meizhi;
END