CREATE PROCEDURE `tb_meizhi_update_fileName`(IN `id` VARCHAR(255), IN `newFileName` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	UPDATE tb_meizhi SET fileName=newFileName where id=id;
END