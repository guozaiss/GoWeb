CREATE PROCEDURE `tb_person_insert`(IN `id` VARCHAR(255), IN `age` INT(11), IN `name` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	INSERT tb_person(id,age,name) VALUES(id,age,name);
END