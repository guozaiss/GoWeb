CREATE PROCEDURE `tb_person_deleteAll`()
  BEGIN
	#Routine body goes here...
	DELETE FROM tb_person;
END