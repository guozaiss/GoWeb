CREATE PROCEDURE `tb_person_update`(IN `id` VARCHAR(255), IN `age` INT(11), IN `name` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	UPDATE tb_person SET age=age ,name=name where id=id;
END