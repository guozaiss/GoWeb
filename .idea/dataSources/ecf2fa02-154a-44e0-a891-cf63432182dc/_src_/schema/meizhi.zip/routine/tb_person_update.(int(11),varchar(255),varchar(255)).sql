CREATE PROCEDURE `tb_person_update`(IN `age` INT(11), IN `name` VARCHAR(255), IN `updateId` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	UPDATE tb_person SET age=age ,name=name where id=updateId;
END