CREATE PROCEDURE `tb_person_deleteById`(IN `deleteId` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	DELETE FROM tb_person WHERE id= deleteId;
END