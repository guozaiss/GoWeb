CREATE PROCEDURE `tb_person_deleteById`(IN `whereBy` VARCHAR(255))
  BEGIN
	#Routine body goes here...
	DELETE FROM tb_person WHERE id= whereBy;
END