CREATE VIEW `showpersondetails` AS
  SELECT
    `meizhi`.`tb_meizhi`.`id`       AS `personId`,
    `meizhi`.`tb_meizhi`.`fileName` AS `fileName`,
    `meizhi`.`tb_person`.`age`      AS `age`
  FROM (`meizhi`.`tb_meizhi`
    JOIN `meizhi`.`tb_person` ON ((`meizhi`.`tb_meizhi`.`id` = `meizhi`.`tb_person`.`id`)))
  ORDER BY `meizhi`.`tb_person`.`id`