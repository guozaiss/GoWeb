CREATE VIEW `sss` AS
  SELECT
    `meizhi`.`tb_meizhi`.`id`       AS `id`,
    `meizhi`.`tb_meizhi`.`fileName` AS `fileName`
  FROM `meizhi`.`tb_meizhi`
  WHERE (`meizhi`.`tb_meizhi`.`id` = 123)