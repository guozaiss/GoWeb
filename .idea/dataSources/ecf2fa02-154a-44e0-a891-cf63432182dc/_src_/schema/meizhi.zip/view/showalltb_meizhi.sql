CREATE VIEW `showalltb_meizhi` AS
  SELECT
    `meizhi`.`tb_meizhi`.`id`       AS `id`,
    `meizhi`.`tb_meizhi`.`fileName` AS `fileName`
  FROM `meizhi`.`tb_meizhi`